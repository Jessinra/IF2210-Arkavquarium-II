var searchData=
[
  ['win',['win',['../class_image_collection.html#a3d0c87dc96db70369fc6019f7c06a632',1,'ImageCollection']]]
];
