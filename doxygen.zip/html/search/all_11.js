var searchData=
[
  ['updateimage',['updateImage',['../class_guppy.html#ae3f8d80be06998e86f74913986f3ef11',1,'Guppy.updateImage()'],['../class_piranha.html#a0050eddae04e0ab20c61611cd88a96bf',1,'Piranha.updateImage()']]]
];
