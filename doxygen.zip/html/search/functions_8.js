var searchData=
[
  ['linkedlist',['LinkedList',['../class_linked_list.html#ae04bfb6ff80214a33132ba72ceb117aa',1,'LinkedList.LinkedList()'],['../class_linked_list.html#a9024088a7e3f1ecf52e20f41a04da1e2',1,'LinkedList.LinkedList(LinkedList&lt; T &gt; l)']]]
];
