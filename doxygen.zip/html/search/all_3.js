var searchData=
[
  ['direction',['direction',['../class_object.html#acbddc5fc6b3a0a26887042822167391b',1,'Object']]]
];
