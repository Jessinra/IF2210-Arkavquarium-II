var searchData=
[
  ['initimage',['initImage',['../class_image_collection.html#a81c0b35282f7699012fb04a052e9e2a3',1,'ImageCollection']]],
  ['inradius',['inRadius',['../class_aquarium.html#a8d1d9a133536a4126a5eebcfe61c8be5',1,'Aquarium.inRadius()'],['../class_guppy.html#a15d536cfd7546d554447aa860dc6792a',1,'Guppy.inRadius()'],['../class_piranha.html#a77cd16296668a615e17cd1061707f259',1,'Piranha.inRadius()'],['../class_siput.html#a445c844568b33083beb40b8b43ea4107',1,'Siput.inRadius()']]],
  ['isempty',['isEmpty',['../class_linked_list.html#a59a883534d0f878ea80b2a772d2c0d6b',1,'LinkedList']]],
  ['ishungry',['isHungry',['../class_fish.html#aa4d669d1ffe1655a62c8b9ea5c477d72',1,'Fish']]]
];
