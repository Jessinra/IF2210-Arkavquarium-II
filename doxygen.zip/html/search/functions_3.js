var searchData=
[
  ['eat',['eat',['../class_guppy.html#ae163eb3ca8bdc509a884b1213dd645d0',1,'Guppy.eat()'],['../class_piranha.html#a3e74d2c04086547a25caade6fc6c4a05',1,'Piranha.eat()']]],
  ['euclidean',['euclidean',['../class_aquarium.html#a3b76bc7fee5eec312060d6a47f0a0e8d',1,'Aquarium.euclidean()'],['../class_guppy.html#aa4fdd6f3bc3081803671eddff5379919',1,'Guppy.euclidean()'],['../class_piranha.html#ad752f3296e9b82cdcf2e18b05fc84204',1,'Piranha.euclidean()']]]
];
