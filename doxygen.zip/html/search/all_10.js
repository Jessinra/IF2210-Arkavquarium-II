var searchData=
[
  ['takecoin',['takeCoin',['../class_siput.html#a302cfcfcbfe53a189d7ccf85086bea8a',1,'Siput']]],
  ['time_5fdelay',['TIME_DELAY',['../class_constants.html#aeedc34f5758225128e90cc8451f39425',1,'Constants']]]
];
