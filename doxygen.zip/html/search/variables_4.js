var searchData=
[
  ['fish_5fhunger_5fdecrease_5frate',['FISH_HUNGER_DECREASE_RATE',['../class_constants.html#af85ecaa57354c1f0d116539b43dc5381',1,'Constants']]],
  ['fish_5fhungry_5fborderline',['FISH_HUNGRY_BORDERLINE',['../class_constants.html#a52ea052ce1c68b900eb9e6e3df526530',1,'Constants']]],
  ['fish_5fmax_5fhunger',['FISH_MAX_HUNGER',['../class_constants.html#a45aab5431a28ca391e56e1a6842c5c64',1,'Constants']]],
  ['fish_5fmax_5ftimer',['FISH_MAX_TIMER',['../class_constants.html#a891bed3cfe32bc4869e502031d1f4e9c',1,'Constants']]],
  ['fish_5ftimer_5fdec',['FISH_TIMER_DEC',['../class_constants.html#ab4c807c06f1fc22c35083d635edcb50f',1,'Constants']]],
  ['food',['food',['../class_image_collection.html#a6fd041352effe1421a564ea02fb32f25',1,'ImageCollection']]],
  ['food_5fmovement_5fspd',['FOOD_MOVEMENT_SPD',['../class_constants.html#a90825cc68690bbd107208826a2da916a',1,'Constants']]],
  ['food_5fprice',['FOOD_PRICE',['../class_constants.html#a9f86fa276bb772cf5c6805e486f909c9',1,'Constants']]],
  ['foodcount',['foodCount',['../class_food.html#abb901fd4d5d3151687c1ea9fd7f64709',1,'Food']]]
];
