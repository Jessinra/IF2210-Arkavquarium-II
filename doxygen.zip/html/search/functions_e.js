var searchData=
[
  ['takecoin',['takeCoin',['../class_siput.html#a302cfcfcbfe53a189d7ccf85086bea8a',1,'Siput']]]
];
