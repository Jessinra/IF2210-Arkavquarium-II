var searchData=
[
  ['buyegg',['buyEgg',['../class_aquarium.html#a09e85e62172d2602fe29077f10629dfb',1,'Aquarium']]],
  ['buyfood',['buyFood',['../class_aquarium.html#a885afb2cf3b96412a20791b5e7cf950b',1,'Aquarium.buyFood()'],['../class_aquarium.html#a6520de7952c97ef7972f353d7d8e4bad',1,'Aquarium.buyFood(double x)']]],
  ['buyguppy',['buyGuppy',['../class_aquarium.html#abe6b76b0b269cee421d4a90ef7f8c035',1,'Aquarium']]],
  ['buypiranha',['buyPiranha',['../class_aquarium.html#accf1a2c7ecdde46dfe3486ad2cf3f3ab',1,'Aquarium']]],
  ['buysnail',['buySnail',['../class_aquarium.html#aac8a1dff985b61e8a0405dd8bfe24f78',1,'Aquarium']]]
];
